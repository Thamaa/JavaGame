package puppy.code;

import com.badlogic.gdx.graphics.Texture;

public class Piezas {
    private Texture gotaBuena;


    public Piezas(Texture gotaBuena) {
        this.gotaBuena = gotaBuena;
    }

    public Texture getGotaBuena() {
        return gotaBuena;
    }
}
